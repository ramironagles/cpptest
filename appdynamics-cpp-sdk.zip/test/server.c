#include <stdio.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>
#define MAX 80
#define PORT 8080
#define SA struct sockaddr

// Function designed for chat between client and server.
void func(int sockfd)
{
    char buff[MAX];
    int n;
    // infinite loop for chat
    for (;;) {
        bzero(buff, MAX);

        // read the message from client and copy it in buffer
        read(sockfd, buff, sizeof(buff));
        // print buffer which contains the client contents
        printf("\nFrom client: %s\t To client : ", buff);
//        bzero(buff, MAX);
        n = 0;
        // copy server message in the buffer
//        while ((buff[n++] = getchar()) != '\n')
 //           ;
        char str[30];
//      strcpy(str, "response ");
        strcpy(str, buff);
        strcat(str, "\n");
        // and send that buffer to client
        write(sockfd, str, sizeof(str));

        // if msg contains "Exit" then server exit and chat ended.
        if (strncmp("exit", buff, 4) == 0) {
            printf("Server Exit...\n");
            break;
        }
    }
}

// Driver function
int main()
{
const char APP_NAME[] = "HK-Server-Client";
const char TIER_NAME[] = "ServerTier";
const char NODE_NAME[] = "ServerNode1";
const char CONTROLLER_HOST[] = "ec2-54-202-228-219.us-west-2.compute.amazonaws.com";
const int CONTROLLER_PORT = 8090;
const char CONTROLLER_ACCOUNT[] = "customer1";
const char CONTROLLER_ACCESS_KEY[] = "467f1a9e-a73b-46b7-bede-c9caad8bb317";
const int CONTROLLER_USE_SSL = 0;

//struct appd_config* cfg = appd_config_init(); // appd_config_init() resets the configuration object and pass back an handle/pointer
//appd_config_set_app_name(cfg, APP_NAME);
//appd_config_set_tier_name(cfg, TIER_NAME);
//appd_config_set_node_name(cfg, NODE_NAME);
//appd_config_set_controller_host(cfg, CONTROLLER_HOST);
//appd_config_set_controller_port(cfg, CONTROLLER_PORT);
//appd_config_set_controller_account(cfg, CONTROLLER_ACCOUNT);
//appd_config_set_controller_access_key(cfg, CONTROLLER_ACCESS_KEY);
//appd_config_set_controller_use_ssl(cfg, CONTROLLER_USE_SSL);
//int initRC = appd_sdk_init(cfg);

//if (initRC) {
      //std::cerr <<  "Error: sdk init: " << initRC << std::endl;
 //     printf("Error: sdk init: ");
        //printf(initRC);
 //     return -1;
//}



    int sockfd, connfd, len;
    struct sockaddr_in servaddr, cli;

    // socket create and verification
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        printf("socket creation failed...\n");
        exit(0);
    }
    else
        printf("Socket successfully created..\n");
    bzero(&servaddr, sizeof(servaddr));

    // assign IP, PORT
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(PORT);

    // Binding newly created socket to given IP and verification
    if ((bind(sockfd, (SA*)&servaddr, sizeof(servaddr))) != 0) {
        printf("socket bind failed...\n");
        exit(0);
    }
    else
        printf("Socket successfully binded..\n");

    // Now server is ready to listen and verification
    if ((listen(sockfd, 5)) != 0) {
        printf("Listen failed...\n");
        exit(0);
    }
    else
        printf("Server listening..\n");
    len = sizeof(cli);

    // Accept the data packet from client and verification
    connfd = accept(sockfd, (SA*)&cli, &len);
    if (connfd < 0) {
        printf("server accept failed...\n");
        exit(0);
    }
    else
        printf("server accept the client...\n");

    // Function for chatting between client and server
    func(connfd);

    // After chatting close the socket
    close(sockfd);
}
